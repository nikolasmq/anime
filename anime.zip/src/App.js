import './App.css';
import Elementos from './component/Elementos';

function App() {
  return (
    <div className="App">
      <div className="container">
        <div className="row">
          <div className="col">
            <Elementos />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
